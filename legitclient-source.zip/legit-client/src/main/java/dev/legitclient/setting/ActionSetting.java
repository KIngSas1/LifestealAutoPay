package dev.legitclient.setting;

import com.google.gson.JsonElement;

/** A button in the module's settings list. Holds no value and is never saved. */
public final class ActionSetting extends Setting<Runnable> {

    public ActionSetting(String name, Runnable action) {
        super(name, action);
    }

    public void run() {
        value.run();
    }

    @Override
    public JsonElement save() {
        return null;
    }

    @Override
    public void load(JsonElement json) {
        // nothing to load
    }
}
