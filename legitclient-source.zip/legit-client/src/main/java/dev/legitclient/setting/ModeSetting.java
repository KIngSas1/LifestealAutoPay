package dev.legitclient.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/** A value picked from a list of named options. */
public final class ModeSetting extends Setting<String> {

    private final List<String> modes = new ArrayList<>();
    private boolean persistent = true;

    public ModeSetting(String name, String defaultMode, String... modes) {
        super(name, defaultMode);
        this.modes.addAll(List.of(modes));
    }

    public List<String> getModes() {
        return modes;
    }

    public boolean is(String mode) {
        return value.equalsIgnoreCase(mode);
    }

    public int index() {
        return Math.max(0, modes.indexOf(value));
    }

    /** Selects the next (+1) or previous (-1) mode, wrapping around. */
    public void cycle(int direction) {
        if (modes.isEmpty()) {
            return;
        }
        set(modes.get(Math.floorMod(index() + direction, modes.size())));
    }

    /** Replaces the available options (used for the profile list). */
    public void setModes(Collection<String> newModes) {
        modes.clear();
        modes.addAll(newModes);
        if (!modes.contains(value) && !modes.isEmpty()) {
            value = modes.get(0);
        }
    }

    /** Marks this setting as not saved to the config file. */
    public ModeSetting transientValue() {
        this.persistent = false;
        return this;
    }

    @Override
    public JsonElement save() {
        return persistent ? new JsonPrimitive(value) : null;
    }

    @Override
    public void load(JsonElement json) {
        if (persistent && json != null && json.isJsonPrimitive()) {
            String saved = json.getAsString();
            if (modes.contains(saved)) {
                set(saved);
            }
        }
    }
}
