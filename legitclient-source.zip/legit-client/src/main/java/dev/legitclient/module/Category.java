package dev.legitclient.module;

/** The panels shown in the click GUI. Add an entry here to get a new panel. */
public enum Category {
    HUD("HUD"),
    VISUAL("Visual"),
    UTILITY("Utility"),
    CLIENT("Client");

    private final String title;

    Category(String title) {
        this.title = title;
    }

    public String title() {
        return title;
    }
}
