package dev.legitclient.module.hud;

import dev.legitclient.setting.BooleanSetting;
import dev.legitclient.setting.ModeSetting;
import dev.legitclient.util.Draw;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;

public final class ArmorStatus extends HudModule {

    private static final EquipmentSlot[] ARMOR = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
    };
    private static final int ROW = 18;

    private final BooleanSetting heldItem = add(new BooleanSetting("Held item", true));
    private final ModeSetting durability = add(new ModeSetting("Durability", "Number", "Number", "Percent", "Off"));

    public ArmorStatus() {
        super("Armor Status", "Shows your armor and its durability", -4, -4);
        enabledByDefault();
    }

    @Override
    protected int contentWidth() {
        return 16 + (durability.is("Off") ? 0 : 4 + Draw.width("100%"));
    }

    @Override
    protected int contentHeight() {
        return rows() * ROW - 2;
    }

    private int rows() {
        return ARMOR.length + (heldItem.on() ? 1 : 0);
    }

    @Override
    protected void draw(DrawContext context, int x, int y) {
        if (mc.player == null) {
            return;
        }
        int row = 0;
        for (EquipmentSlot slot : ARMOR) {
            drawStack(context, mc.player.getEquippedStack(slot), x, y + row * ROW);
            row++;
        }
        if (heldItem.on()) {
            drawStack(context, mc.player.getMainHandStack(), x, y + row * ROW);
        }
    }

    private void drawStack(DrawContext context, ItemStack stack, int x, int y) {
        if (stack.isEmpty()) {
            return;
        }
        context.drawItem(stack, x, y);

        String label = null;
        int labelColor = textColor();
        if (stack.isDamageable() && !durability.is("Off")) {
            int max = stack.getMaxDamage();
            int left = max - stack.getDamage();
            label = durability.is("Percent") ? Math.round(left * 100f / max) + "%" : Integer.toString(left);
            labelColor = Draw.blend(0xFFFF5555, 0xFF55FF55, left / (float) max);
        } else if (stack.getCount() > 1) {
            label = "x" + stack.getCount();
        }
        if (label != null) {
            Draw.text(context, label, x + 20, y + 4, labelColor, shadow.on());
        }
    }
}
