package dev.legitclient.module.hud;

import java.util.List;

public final class Fps extends TextHudModule {

    public Fps() {
        super("FPS", "Frames per second", 4, 16);
        enabledByDefault();
    }

    @Override
    protected List<String> buildLines() {
        return List.of("FPS: " + mc.getCurrentFps());
    }
}
