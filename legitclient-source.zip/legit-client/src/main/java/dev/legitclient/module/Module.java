package dev.legitclient.module;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import dev.legitclient.config.ConfigManager;
import dev.legitclient.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Base class for every feature. To add a module:
 * <ol>
 *   <li>extend this class (or {@code HudModule} / {@code TextHudModule} for HUD elements),</li>
 *   <li>declare settings with {@link #add(Setting)},</li>
 *   <li>override the hooks you need,</li>
 *   <li>register it in {@link ModuleManager#init()}.</li>
 * </ol>
 */
public abstract class Module {

    protected static final MinecraftClient mc = MinecraftClient.getInstance();

    private final String name;
    private final String description;
    private final Category category;
    private final List<Setting<?>> settings = new ArrayList<>();

    private boolean enabled;
    private boolean defaultEnabled;
    private int key = -1;
    private BindMode bindMode = BindMode.TOGGLE;

    /** Last polled state of the bound key. Managed by {@link ModuleManager}. */
    boolean keyDown;

    protected Module(String name, String description, Category category) {
        this.name = name;
        this.description = description;
        this.category = category;
    }

    // ------------------------------------------------------------------ hooks

    /** Called when the module is turned on. */
    protected void onEnable() {
    }

    /** Called when the module is turned off. */
    protected void onDisable() {
    }

    /** Called every client tick while enabled and a world is loaded. */
    public void onTick() {
    }

    /** Called every frame while enabled (HUD layer). Use for 2D drawing. */
    public void onRender2D(DrawContext context) {
    }

    // -------------------------------------------------------------- behaviour

    /** False for modules that only hold settings (their row expands instead of toggling). */
    public boolean isToggleable() {
        return true;
    }

    /** False for modules whose on/off state should not be restored on startup. */
    protected boolean savesEnabledState() {
        return true;
    }

    /** Extra data saved alongside the module (e.g. HUD position). */
    protected void writeExtra(JsonObject json) {
    }

    protected void readExtra(JsonObject json) {
    }

    // ------------------------------------------------------------------ state

    public final void toggle() {
        setEnabled(!enabled);
    }

    public final void setEnabled(boolean state) {
        if (enabled == state) {
            return;
        }
        enabled = state;
        if (state) {
            onEnable();
        } else {
            onDisable();
        }
        if (persistsEnabledState()) {
            ConfigManager.markDirty();
        }
    }

    /** Hold-to-use modules are never restored as "on" after a restart. */
    private boolean persistsEnabledState() {
        return savesEnabledState() && bindMode == BindMode.TOGGLE;
    }

    public final boolean isEnabled() {
        return enabled;
    }

    // ---------------------------------------------------------------- binding

    public final int getKey() {
        return key;
    }

    public final void setKey(int key) {
        this.key = key;
        ConfigManager.markDirty();
    }

    public final BindMode getBindMode() {
        return bindMode;
    }

    public final void setBindMode(BindMode mode) {
        this.bindMode = mode;
        ConfigManager.markDirty();
    }

    /** Sets the bind used when no config exists yet. */
    protected final void defaultBind(int key, BindMode mode) {
        this.key = key;
        this.bindMode = mode;
    }

    /** Makes the module start enabled when no config exists yet. */
    protected final void enabledByDefault() {
        this.defaultEnabled = true;
    }

    final void applyDefaultState() {
        setEnabled(defaultEnabled);
    }

    // --------------------------------------------------------------- settings

    protected final <S extends Setting<?>> S add(S setting) {
        settings.add(setting);
        return setting;
    }

    public final List<Setting<?>> getSettings() {
        return Collections.unmodifiableList(settings);
    }

    public final String getName() {
        return name;
    }

    public final String getDescription() {
        return description;
    }

    public final Category getCategory() {
        return category;
    }

    // ------------------------------------------------------------ persistence

    public final JsonObject toJson() {
        JsonObject json = new JsonObject();
        if (persistsEnabledState()) {
            json.addProperty("enabled", enabled);
        }
        json.addProperty("key", key);
        json.addProperty("bindMode", bindMode.name());

        JsonObject values = new JsonObject();
        for (Setting<?> setting : settings) {
            JsonElement saved = setting.save();
            if (saved != null) {
                values.add(setting.getName(), saved);
            }
        }
        json.add("settings", values);
        writeExtra(json);
        return json;
    }

    public final void fromJson(JsonObject json) {
        if (json.has("key")) {
            key = json.get("key").getAsInt();
        }
        if (json.has("bindMode")) {
            try {
                bindMode = BindMode.valueOf(json.get("bindMode").getAsString());
            } catch (IllegalArgumentException ignored) {
                bindMode = BindMode.TOGGLE;
            }
        }
        if (json.has("settings") && json.get("settings").isJsonObject()) {
            JsonObject values = json.getAsJsonObject("settings");
            for (Setting<?> setting : settings) {
                if (values.has(setting.getName())) {
                    try {
                        setting.load(values.get(setting.getName()));
                    } catch (RuntimeException ignored) {
                        // keep the default if the saved value is malformed
                    }
                }
            }
        }
        readExtra(json);
        if (persistsEnabledState() && json.has("enabled")) {
            setEnabled(json.get("enabled").getAsBoolean());
        }
    }
}
