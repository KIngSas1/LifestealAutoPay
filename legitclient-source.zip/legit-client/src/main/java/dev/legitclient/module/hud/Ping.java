package dev.legitclient.module.hud;

import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;

import java.util.List;

public final class Ping extends TextHudModule {

    public Ping() {
        super("Ping", "Latency to the server", 4, 40);
    }

    @Override
    protected List<String> buildLines() {
        ClientPlayNetworkHandler network = mc.getNetworkHandler();
        PlayerListEntry entry = network == null || mc.player == null
                ? null
                : network.getPlayerListEntry(mc.player.getUuid());
        return List.of(entry == null ? "Ping: --" : "Ping: " + entry.getLatency() + " ms");
    }
}
