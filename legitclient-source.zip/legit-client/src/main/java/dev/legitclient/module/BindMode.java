package dev.legitclient.module;

public enum BindMode {
    /** Pressing the key flips the module on/off. */
    TOGGLE,
    /** The module is on only while the key is held. */
    HOLD
}
