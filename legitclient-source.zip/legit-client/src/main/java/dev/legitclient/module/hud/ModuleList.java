package dev.legitclient.module.hud;

import dev.legitclient.LegitClient;
import dev.legitclient.module.Category;
import dev.legitclient.module.Module;
import dev.legitclient.setting.BooleanSetting;
import dev.legitclient.setting.ModeSetting;
import dev.legitclient.util.Draw;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Shows the names of all enabled modules (the classic "array list"). */
public final class ModuleList extends TextHudModule {

    private final BooleanSetting showHud = add(new BooleanSetting("Show HUD modules", false));
    private final ModeSetting sort = add(new ModeSetting("Sort", "Length", "Length", "Alphabetical"));

    public ModuleList() {
        super("Module List", "Lists the enabled modules", -4, 4);
    }

    @Override
    protected boolean alignRight() {
        return true;
    }

    @Override
    protected List<String> buildLines() {
        List<String> names = new ArrayList<>();
        for (Module module : LegitClient.modules().all()) {
            boolean hidden = module == this
                    || module.getCategory() == Category.CLIENT
                    || (module.getCategory() == Category.HUD && !showHud.on());
            if (module.isEnabled() && !hidden) {
                names.add(module.getName());
            }
        }
        if (sort.is("Length")) {
            names.sort(Comparator.comparingInt(Draw::width).reversed());
        } else {
            names.sort(String::compareToIgnoreCase);
        }
        return names;
    }
}
