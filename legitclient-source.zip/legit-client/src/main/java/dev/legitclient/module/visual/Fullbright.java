package dev.legitclient.module.visual;

import dev.legitclient.module.Category;
import dev.legitclient.module.Module;
import dev.legitclient.setting.NumberSetting;

/**
 * Raises the gamma option so dark areas are fully lit. The actual override
 * lives in {@code SimpleOptionMixin}; nothing is written to your options file.
 */
public final class Fullbright extends Module {

    private static Fullbright instance;

    private final NumberSetting gamma = add(new NumberSetting("Gamma", 12, 2, 30, 1));

    public Fullbright() {
        super("Fullbright", "Makes everything fully bright", Category.VISUAL);
        instance = this;
    }

    public static boolean isActive() {
        return instance != null && instance.isEnabled();
    }

    public static double gamma() {
        return instance == null ? 1.0 : instance.gamma.getDouble();
    }
}
