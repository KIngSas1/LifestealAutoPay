package dev.legitclient.module.utility;

import dev.legitclient.module.Category;
import dev.legitclient.module.Module;

/**
 * Holds the vanilla sprint key for you while you walk forward — the same thing
 * as the "Toggle Sprint" accessibility option, so all vanilla sprint rules still apply.
 */
public final class ToggleSprint extends Module {

    public ToggleSprint() {
        super("Toggle Sprint", "Sprints automatically while moving forward", Category.UTILITY);
    }

    @Override
    public void onTick() {
        if (mc.currentScreen == null && mc.options.forwardKey.isPressed()) {
            mc.options.sprintKey.setPressed(true);
        }
    }

    @Override
    protected void onDisable() {
        mc.options.sprintKey.setPressed(false);
    }
}
