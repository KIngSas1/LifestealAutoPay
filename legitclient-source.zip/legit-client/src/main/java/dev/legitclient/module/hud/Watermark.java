package dev.legitclient.module.hud;

import dev.legitclient.LegitClient;

import java.util.List;

public final class Watermark extends TextHudModule {

    public Watermark() {
        super("Watermark", "Shows the client name", 4, 4);
        enabledByDefault();
    }

    @Override
    protected List<String> buildLines() {
        return List.of(LegitClient.NAME + " " + LegitClient.VERSION);
    }
}
