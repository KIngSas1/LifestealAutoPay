package dev.legitclient.module.hud;

import com.google.gson.JsonObject;
import dev.legitclient.config.ConfigManager;
import dev.legitclient.module.Category;
import dev.legitclient.module.Module;
import dev.legitclient.setting.BooleanSetting;
import dev.legitclient.setting.ColorSetting;
import dev.legitclient.util.Draw;
import net.minecraft.client.gui.DrawContext;

/**
 * Base class for on-screen HUD elements. Subclasses only describe their size
 * and how to draw themselves; placement, clamping, saving the position and
 * dragging in the click GUI are handled here.
 *
 * <p>Default positions: a negative value is a margin from the right / bottom edge
 * (e.g. {@code -4} = 4px from the edge).
 */
public abstract class HudModule extends Module {

    private static final int PADDING = 3;
    private static final int MIN_WIDTH = 30;
    private static final int MIN_HEIGHT = 10;

    protected final BooleanSetting shadow = add(new BooleanSetting("Text shadow", true));
    protected final BooleanSetting background = add(new BooleanSetting("Background", false));
    protected final ColorSetting color = add(new ColorSetting("Color", "White"));

    private final int defaultX;
    private final int defaultY;
    private int x;
    private int y;
    private int width;
    private int height;
    private boolean placed;

    protected HudModule(String name, String description, int defaultX, int defaultY) {
        super(name, description, Category.HUD);
        this.defaultX = defaultX;
        this.defaultY = defaultY;
    }

    // -------------------------------------------------------- subclass contract

    /** Called first on every frame — gather the data you are going to draw. */
    protected void prepare() {
    }

    /** Width of the content in pixels (without padding). */
    protected abstract int contentWidth();

    /** Height of the content in pixels (without padding). */
    protected abstract int contentHeight();

    /** Draw the content with its top-left corner at (x, y). */
    protected abstract void draw(DrawContext context, int x, int y);

    // ----------------------------------------------------------------- helpers

    protected final int textColor() {
        return color.argb();
    }

    protected final void text(DrawContext context, String text, int x, int y) {
        Draw.text(context, text, x, y, textColor(), shadow.on());
    }

    // --------------------------------------------------------------- rendering

    public final void renderHud(DrawContext context, int screenWidth, int screenHeight) {
        prepare();
        int w = Math.max(MIN_WIDTH, contentWidth()) + PADDING * 2;
        int h = Math.max(MIN_HEIGHT, contentHeight()) + PADDING * 2;

        if (!placed) {
            x = defaultX >= 0 ? defaultX : screenWidth - w + defaultX;
            y = defaultY >= 0 ? defaultY : screenHeight - h + defaultY;
            placed = true;
        }
        x = Math.max(0, Math.min(x, screenWidth - w));
        y = Math.max(0, Math.min(y, screenHeight - h));
        width = w;
        height = h;

        if (background.on()) {
            Draw.rounded(context, x, y, w, h, 3, 0x90000000);
        }
        draw(context, x + PADDING, y + PADDING);
    }

    // ---------------------------------------------------- dragging (click GUI)

    public final boolean contains(double mouseX, double mouseY) {
        return Draw.inside(mouseX, mouseY, x, y, width, height);
    }

    public final void moveTo(int newX, int newY) {
        x = newX;
        y = newY;
        placed = true;
        ConfigManager.markDirty();
    }

    public final int getX() {
        return x;
    }

    public final int getY() {
        return y;
    }

    public final int getWidth() {
        return width;
    }

    public final int getHeight() {
        return height;
    }

    // ------------------------------------------------------------- persistence

    @Override
    protected void writeExtra(JsonObject json) {
        if (placed) {
            json.addProperty("x", x);
            json.addProperty("y", y);
        }
    }

    @Override
    protected void readExtra(JsonObject json) {
        if (json.has("x") && json.has("y")) {
            x = json.get("x").getAsInt();
            y = json.get("y").getAsInt();
            placed = true;
        }
    }
}
