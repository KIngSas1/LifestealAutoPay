package dev.legitclient.util;

import org.lwjgl.glfw.GLFW;

import java.util.HashMap;
import java.util.Map;

/** Human readable names for GLFW key codes (used by the bind button). */
public final class KeyNames {

    private static final Map<Integer, String> SPECIAL = new HashMap<>();

    static {
        SPECIAL.put(GLFW.GLFW_KEY_SPACE, "Space");
        SPECIAL.put(GLFW.GLFW_KEY_TAB, "Tab");
        SPECIAL.put(GLFW.GLFW_KEY_ENTER, "Enter");
        SPECIAL.put(GLFW.GLFW_KEY_LEFT_SHIFT, "LShift");
        SPECIAL.put(GLFW.GLFW_KEY_RIGHT_SHIFT, "RShift");
        SPECIAL.put(GLFW.GLFW_KEY_LEFT_CONTROL, "LCtrl");
        SPECIAL.put(GLFW.GLFW_KEY_RIGHT_CONTROL, "RCtrl");
        SPECIAL.put(GLFW.GLFW_KEY_LEFT_ALT, "LAlt");
        SPECIAL.put(GLFW.GLFW_KEY_RIGHT_ALT, "RAlt");
        SPECIAL.put(GLFW.GLFW_KEY_UP, "Up");
        SPECIAL.put(GLFW.GLFW_KEY_DOWN, "Down");
        SPECIAL.put(GLFW.GLFW_KEY_LEFT, "Left");
        SPECIAL.put(GLFW.GLFW_KEY_RIGHT, "Right");
        SPECIAL.put(GLFW.GLFW_KEY_INSERT, "Insert");
        SPECIAL.put(GLFW.GLFW_KEY_HOME, "Home");
        SPECIAL.put(GLFW.GLFW_KEY_END, "End");
        SPECIAL.put(GLFW.GLFW_KEY_PAGE_UP, "PgUp");
        SPECIAL.put(GLFW.GLFW_KEY_PAGE_DOWN, "PgDn");
        SPECIAL.put(GLFW.GLFW_KEY_CAPS_LOCK, "Caps");
        SPECIAL.put(GLFW.GLFW_KEY_GRAVE_ACCENT, "`");
    }

    private KeyNames() {
    }

    public static String of(int key) {
        if (key <= 0) {
            return "None";
        }
        String special = SPECIAL.get(key);
        if (special != null) {
            return special;
        }
        if (key >= GLFW.GLFW_KEY_F1 && key <= GLFW.GLFW_KEY_F25) {
            return "F" + (key - GLFW.GLFW_KEY_F1 + 1);
        }
        if ((key >= GLFW.GLFW_KEY_A && key <= GLFW.GLFW_KEY_Z)
                || (key >= GLFW.GLFW_KEY_0 && key <= GLFW.GLFW_KEY_9)) {
            return String.valueOf((char) key);
        }
        if (key >= GLFW.GLFW_KEY_KP_0 && key <= GLFW.GLFW_KEY_KP_9) {
            return "Num" + (key - GLFW.GLFW_KEY_KP_0);
        }
        try {
            String name = GLFW.glfwGetKeyName(key, 0);
            if (name != null) {
                return name.toUpperCase();
            }
        } catch (Throwable ignored) {
            // some GLFW layers (mobile launchers) don't implement key names
        }
        return "Key " + key;
    }
}
