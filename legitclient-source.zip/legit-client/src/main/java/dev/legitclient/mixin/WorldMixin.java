package dev.legitclient.mixin;

import dev.legitclient.module.visual.WeatherChanger;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Weather Changer: overrides the rain / thunder strength the client renders. */
@Mixin(World.class)
public abstract class WorldMixin {

    @Inject(method = "getRainGradient", at = @At("RETURN"), cancellable = true, require = 0)
    private void legitclient$rain(CallbackInfoReturnable<Float> cir) {
        if (WeatherChanger.isActive()) {
            cir.setReturnValue(WeatherChanger.rain(cir.getReturnValueF()));
        }
    }

    @Inject(method = "getThunderGradient", at = @At("RETURN"), cancellable = true, require = 0)
    private void legitclient$thunder(CallbackInfoReturnable<Float> cir) {
        if (WeatherChanger.isActive()) {
            cir.setReturnValue(WeatherChanger.thunder(cir.getReturnValueF()));
        }
    }
}
