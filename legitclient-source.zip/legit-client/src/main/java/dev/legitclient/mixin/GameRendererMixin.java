package dev.legitclient.mixin;

import dev.legitclient.module.visual.NoHurtCam;
import dev.legitclient.module.visual.Zoom;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Hooks for the Zoom and No Hurt Cam modules. The handlers deliberately take only
 * the callback info (no target arguments) so they keep working if Mojang changes
 * the parameter lists; {@code require = 0} makes a missing target a warning, not a crash.
 */
@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {

    @Inject(method = "getFov", at = @At("RETURN"), cancellable = true, require = 0)
    private void legitclient$zoom(CallbackInfoReturnable<Float> cir) {
        float divisor = Zoom.fovDivisor();
        if (divisor != 1f) {
            cir.setReturnValue(cir.getReturnValueF() / divisor);
        }
    }

    @Inject(method = "tiltViewWhenHurt", at = @At("HEAD"), cancellable = true, require = 0)
    private void legitclient$noHurtCam(CallbackInfo ci) {
        if (NoHurtCam.isActive()) {
            ci.cancel();
        }
    }
}
