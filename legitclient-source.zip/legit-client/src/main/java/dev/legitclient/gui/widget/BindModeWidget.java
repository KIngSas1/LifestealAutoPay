package dev.legitclient.gui.widget;

import dev.legitclient.gui.Theme;
import dev.legitclient.module.BindMode;
import dev.legitclient.module.Module;
import net.minecraft.client.gui.DrawContext;

/** Toggle / Hold selector, only shown once the module has a key. */
final class BindModeWidget extends SettingWidget {

    private final Module module;

    BindModeWidget(Module module) {
        this.module = module;
    }

    @Override
    public int height() {
        return 14;
    }

    @Override
    public boolean isVisible() {
        return module.isToggleable() && module.getKey() > 0;
    }

    @Override
    protected void renderContent(DrawContext context, int mouseX, int mouseY) {
        paintRow(context, hovered(mouseX, mouseY));
        label(context, "Bind mode", Theme.TEXT_DIM);
        rightText(context, module.getBindMode() == BindMode.TOGGLE ? "Toggle" : "Hold", Theme.accent());
    }

    @Override
    public void click(double mouseX, double mouseY, int button) {
        if (button == 0 || button == 1) {
            module.setBindMode(module.getBindMode() == BindMode.TOGGLE ? BindMode.HOLD : BindMode.TOGGLE);
        }
    }
}
