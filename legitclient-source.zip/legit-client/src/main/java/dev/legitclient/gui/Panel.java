package dev.legitclient.gui;

import dev.legitclient.LegitClient;
import dev.legitclient.module.Category;
import dev.legitclient.module.Module;
import dev.legitclient.util.Draw;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

/** One draggable column holding all modules of a category. Tap the header arrow (or right-click) to collapse. */
final class Panel {

    private final Category category;
    private final List<ModuleButton> buttons = new ArrayList<>();
    private int x;
    private int y;
    private boolean open = true;
    private boolean dragging;
    private int dragOffsetX;
    private int dragOffsetY;
    private int scroll;

    Panel(Category category, int defaultX, int defaultY) {
        this.category = category;
        for (Module module : LegitClient.modules().inCategory(category)) {
            buttons.add(new ModuleButton(module));
        }
        int[] saved = LegitClient.config().getPanelPosition(category.title());
        this.x = saved != null ? saved[0] : defaultX;
        this.y = saved != null ? saved[1] : defaultY;
    }

    /** Vertical scroll shared by all panels, set by the screen. */
    void setScroll(int scroll) {
        this.scroll = scroll;
    }

    /** Bottom edge in unscrolled coordinates (used to compute how far the screen may scroll). */
    int bottom() {
        return y + height();
    }

    private int top() {
        return y - scroll;
    }

    private int height() {
        int h = Theme.HEADER_HEIGHT;
        if (open) {
            for (ModuleButton button : buttons) {
                h += button.height();
            }
        }
        return h;
    }

    void render(DrawContext context, int mouseX, int mouseY) {
        int w = Theme.PANEL_WIDTH;
        int top = top();
        Draw.rect(context, x, top, w, Theme.HEADER_HEIGHT, Theme.HEADER);
        Draw.rect(context, x, top + Theme.HEADER_HEIGHT - 1, w, 1, Theme.accent());
        Draw.text(context, category.title(), x + Theme.PADDING, top + 5, Theme.TEXT);
        Draw.text(context, open ? "v" : ">", x + w - Theme.PADDING - 4, top + 5, Theme.TEXT_DIM);

        if (!open) {
            return;
        }
        int cursor = top + Theme.HEADER_HEIGHT;
        for (ModuleButton button : buttons) {
            button.render(context, x, cursor, w, mouseX, mouseY);
            cursor += button.height();
        }
    }

    /** @return the module whose row is under the mouse, or null. */
    Module hoveredModule(double mouseX, double mouseY) {
        if (open) {
            for (ModuleButton button : buttons) {
                if (button.rowHovered(mouseX, mouseY)) {
                    return button.getModule();
                }
            }
        }
        return null;
    }

    /** @return true if the click was inside this panel (so nothing below it gets it). */
    boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (Draw.inside(mouseX, mouseY, x, top(), Theme.PANEL_WIDTH, Theme.HEADER_HEIGHT)) {
            // Left click on the arrow (or right click anywhere) collapses; otherwise left click starts a drag.
            boolean arrow = mouseX >= x + Theme.PANEL_WIDTH - 22;
            if (button == 1 || (button == 0 && arrow)) {
                open = !open;
            } else if (button == 0) {
                dragging = true;
                dragOffsetX = (int) mouseX - x;
                dragOffsetY = (int) mouseY - top();
            }
            return true;
        }
        if (open) {
            for (ModuleButton moduleButton : buttons) {
                if (moduleButton.mouseClicked(mouseX, mouseY, button)) {
                    return true;
                }
            }
        }
        return Draw.inside(mouseX, mouseY, x, top(), Theme.PANEL_WIDTH, height());
    }

    void mouseDragged(double mouseX, double mouseY) {
        if (dragging) {
            x = Math.max(0, (int) mouseX - dragOffsetX);
            y = Math.max(0, (int) mouseY - dragOffsetY + scroll);
        }
        buttons.forEach(button -> button.mouseDragged(mouseX));
    }

    void mouseReleased() {
        if (dragging) {
            dragging = false;
            LegitClient.config().setPanelPosition(category.title(), x, y);
        }
        buttons.forEach(ModuleButton::mouseReleased);
    }
}
