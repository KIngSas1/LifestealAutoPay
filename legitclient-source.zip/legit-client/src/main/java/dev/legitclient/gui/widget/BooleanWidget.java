package dev.legitclient.gui.widget;

import dev.legitclient.gui.Theme;
import dev.legitclient.setting.BooleanSetting;
import dev.legitclient.util.Draw;
import net.minecraft.client.gui.DrawContext;

final class BooleanWidget extends SettingWidget {

    private final BooleanSetting setting;

    BooleanWidget(BooleanSetting setting) {
        this.setting = setting;
    }

    @Override
    public int height() {
        return 14;
    }

    @Override
    public boolean isVisible() {
        return setting.isVisible();
    }

    @Override
    protected void renderContent(DrawContext context, int mouseX, int mouseY) {
        paintRow(context, hovered(mouseX, mouseY));
        label(context, setting.getName(), setting.on() ? Theme.TEXT : Theme.TEXT_DIM);

        int pillW = 16;
        int pillX = x + w - Theme.PADDING - pillW;
        int pillY = y + 3;
        Draw.rounded(context, pillX, pillY, pillW, 8, 4, setting.on() ? Theme.accent() : Theme.TRACK);
        int knobX = setting.on() ? pillX + pillW - 7 : pillX + 1;
        Draw.rounded(context, knobX, pillY + 1, 6, 6, 3, 0xFFFFFFFF);
    }

    @Override
    public void click(double mouseX, double mouseY, int button) {
        if (button == 0) {
            setting.toggle();
        }
    }
}
