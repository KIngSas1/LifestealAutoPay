package dev.legitclient.gui;

import dev.legitclient.LegitClient;
import dev.legitclient.gui.widget.SettingWidget;
import dev.legitclient.module.Category;
import dev.legitclient.module.Module;
import dev.legitclient.module.client.ClickGuiModule;
import dev.legitclient.module.hud.HudModule;
import dev.legitclient.util.Draw;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * The click GUI. Panels per category, plus drag-and-drop editing of the enabled
 * HUD elements while the screen is open.
 *
 * <p>All Minecraft input-event types ({@link Click}, {@link KeyInput}) are confined to this
 * class; the panels and widgets only see plain coordinates, button numbers and GLFW key codes.
 */
public final class ClickGuiScreen extends Screen {

    private static final int PANEL_SPACING = 8;

    private final List<Panel> panels = new ArrayList<>();
    private HudModule draggedHud;
    private int dragOffsetX;
    private int dragOffsetY;
    private int scroll;
    private boolean scrollingBackground;

    public ClickGuiScreen() {
        super(Text.literal("Click GUI"));
        int x = 10;
        for (Category category : Category.values()) {
            panels.add(new Panel(category, x, 14));
            x += Theme.PANEL_WIDTH + PANEL_SPACING;
        }
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    // --------------------------------------------------------------- rendering

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        if (ClickGuiModule.dimBackground()) {
            Draw.rect(context, 0, 0, width, height, 0x78000000);
        }
        setScroll(scroll);
        renderHudOutlines(context);

        for (Panel panel : panels) {
            panel.render(context, mouseX, mouseY);
        }
        renderTooltip(context, mouseX, mouseY);
        renderCloseButton(context, mouseX, mouseY);

        String hint = "Tap: toggle   Tap +/-: settings   Drag empty space: scroll   Drag HUD elements to move them";
        Draw.text(context, hint, (width - Draw.width(hint)) / 2, height - 12, Theme.TEXT_DIM, true);
    }

    // ---- close button (the only way out on devices without an Esc key) and scrolling

    private boolean overClose(double mouseX, double mouseY) {
        return Draw.inside(mouseX, mouseY, width - 26, 6, 20, 20);
    }

    private void renderCloseButton(DrawContext context, int mouseX, int mouseY) {
        boolean hover = overClose(mouseX, mouseY);
        Draw.rounded(context, width - 26, 6, 20, 20, 3, hover ? Theme.accent() : 0xE0101015);
        Draw.centeredText(context, "X", width - 26, 6, 20, 20, Theme.TEXT, false);
    }

    /** Scrolls all panels together; clamped so the lowest panel can just be reached. */
    private void setScroll(int value) {
        int lowest = 0;
        for (Panel panel : panels) {
            lowest = Math.max(lowest, panel.bottom());
        }
        scroll = Math.max(0, Math.min(value, Math.max(0, lowest + 24 - height)));
        panels.forEach(panel -> panel.setScroll(scroll));
    }

    private void renderHudOutlines(DrawContext context) {
        if (MinecraftClient.getInstance().world == null) {
            return; // on the title screen there are no HUD elements to place
        }
        for (Module module : LegitClient.modules().all()) {
            if (module instanceof HudModule hud && hud.isEnabled()) {
                int color = Draw.withAlpha(Theme.accent(), hud == draggedHud ? 0xFF : 0x90);
                Draw.outline(context, hud.getX(), hud.getY(), hud.getWidth(), hud.getHeight(), color);
                Draw.text(context, hud.getName(), hud.getX(), hud.getY() - 10, color, true);
            }
        }
    }

    private void renderTooltip(DrawContext context, int mouseX, int mouseY) {
        for (int i = panels.size() - 1; i >= 0; i--) {
            Module hovered = panels.get(i).hoveredModule(mouseX, mouseY);
            if (hovered != null) {
                String text = hovered.getDescription();
                int w = Draw.width(text) + 8;
                int x = Math.min(mouseX + 10, width - w - 2);
                int y = Math.min(mouseY + 10, height - 16);
                Draw.rect(context, x, y, w, 14, 0xF0101015);
                Draw.outline(context, x, y, w, 14, Theme.accent());
                Draw.text(context, text, x + 4, y + 3, Theme.TEXT);
                return;
            }
        }
    }

    // ------------------------------------------------------------------- input

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mouseX = click.x();
        double mouseY = click.y();
        int button = click.button();

        SettingWidget.releaseFocus();

        if (button == 0 && overClose(mouseX, mouseY)) {
            close();
            return true;
        }

        // Topmost panel first; a clicked panel moves to the front.
        for (int i = panels.size() - 1; i >= 0; i--) {
            Panel panel = panels.get(i);
            if (panel.mouseClicked(mouseX, mouseY, button)) {
                panels.remove(i);
                panels.add(panel);
                return true;
            }
        }

        if (button == 0) {
            for (Module module : LegitClient.modules().all()) {
                if (module instanceof HudModule hud && hud.isEnabled() && hud.contains(mouseX, mouseY)) {
                    draggedHud = hud;
                    dragOffsetX = (int) mouseX - hud.getX();
                    dragOffsetY = (int) mouseY - hud.getY();
                    return true;
                }
            }
            scrollingBackground = true;
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseDragged(Click click, double offsetX, double offsetY) {
        if (draggedHud != null) {
            draggedHud.moveTo((int) click.x() - dragOffsetX, (int) click.y() - dragOffsetY);
            return true;
        }
        if (scrollingBackground) {
            setScroll(scroll - (int) offsetY);
            return true;
        }
        for (Panel panel : panels) {
            panel.mouseDragged(click.x(), click.y());
        }
        return super.mouseDragged(click, offsetX, offsetY);
    }

    @Override
    public boolean mouseReleased(Click click) {
        draggedHud = null;
        scrollingBackground = false;
        panels.forEach(Panel::mouseReleased);
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        setScroll(scroll - (int) (verticalAmount * 20));
        return true;
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int key = input.key();

        SettingWidget focused = SettingWidget.getFocused();
        if (focused != null && focused.keyPressed(key)) {
            return true;
        }

        ClickGuiModule module = LegitClient.modules().get(ClickGuiModule.class);
        if (key == GLFW.GLFW_KEY_ESCAPE || (module.getKey() > 0 && key == module.getKey())) {
            close();
            return true;
        }
        return super.keyPressed(input);
    }

    @Override
    public void removed() {
        SettingWidget.releaseFocus();
        draggedHud = null;
        LegitClient.modules().get(ClickGuiModule.class).setEnabled(false);
        LegitClient.config().save();
    }
}
