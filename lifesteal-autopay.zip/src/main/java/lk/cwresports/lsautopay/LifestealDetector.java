package lk.cwresports.lsautopay;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.util.Formatting;

import java.util.Locale;

/**
 * ALL "am I in Lifesteal?" logic lives in this file.
 * To change how Lifesteal is detected, edit {@link #detectionText} (or add a mode in AutoPayConfig).
 */
public final class LifestealDetector {
    private LifestealDetector() {}

    /** True only while connected to the configured server (mc.cwresports.lk). */
    public static boolean isTargetServer(MinecraftClient mc, AutoPayConfig cfg) {
        ServerInfo info = mc.getCurrentServerEntry();
        if (info == null || info.address == null) return false;
        String host = info.address.trim().toLowerCase(Locale.ROOT);
        int colon = host.lastIndexOf(':');
        if (colon > 0 && host.indexOf(':') == colon) host = host.substring(0, colon); // strip :port
        while (host.endsWith(".")) host = host.substring(0, host.length() - 1);
        return host.equals(cfg.serverHost.trim().toLowerCase(Locale.ROOT));
    }

    /** The text that is searched for the Lifesteal keyword. Change this to change detection. */
    public static String detectionText(MinecraftClient mc, AutoPayConfig cfg) {
        if (mc.world == null) return null;
        switch (cfg.detectionMode) {
            case DIMENSION:
                return mc.world.getRegistryKey().getValue().toString();
            case SCOREBOARD_TITLE:
            default:
                Scoreboard sb = mc.world.getScoreboard();
                ScoreboardObjective obj = sb.getObjectiveForSlot(ScoreboardDisplaySlot.SIDEBAR);
                if (obj == null) return null;
                return Formatting.strip(obj.getDisplayName().getString());
        }
    }

    public static boolean isInLifesteal(MinecraftClient mc, AutoPayConfig cfg) {
        if (mc.world == null || mc.player == null) return false;
        String text = detectionText(mc, cfg);
        return text != null && text.toLowerCase(Locale.ROOT).contains(cfg.lifestealKeyword.toLowerCase(Locale.ROOT));
    }

    /** On the right server AND in Lifesteal. */
    public static boolean isActive(MinecraftClient mc, AutoPayConfig cfg) {
        return isTargetServer(mc, cfg) && isInLifesteal(mc, cfg);
    }
}
