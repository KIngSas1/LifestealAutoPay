package lk.cwresports.lsautopay;

import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AutoPayClient implements ClientModInitializer {
    public static final Logger LOG = LoggerFactory.getLogger("LifestealAutoPay");

    private static final int POLL_INTERVAL_TICKS = 10; // detection check twice a second
    private static final int LEAVE_GRACE_POLLS = 5;    // ~2.5 s of "not in Lifesteal" before cancelling (sidebar flicker)

    private final PayoutRunner runner = new PayoutRunner();
    private boolean inLifesteal = false;
    private int missCount = 0;
    private int pollCooldown = 0;

    @Override
    public void onInitializeClient() {
        AutoPayConfig.get(); // load config now

        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);

        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> resetState(client, "joined a new world/server"));
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> resetState(client, "disconnected"));

        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (overlay) return;
            try {
                runner.onGameMessage(Formatting.strip(message.getString()));
            } catch (Throwable t) {
                LOG.error("Error handling message", t);
            }
        });

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("lspay")
                        .then(ClientCommandManager.literal("status").executes(this::cmdStatus))
                        .then(ClientCommandManager.literal("players").executes(this::cmdPlayers))
                        .then(ClientCommandManager.literal("cancel").executes(ctx -> {
                            runner.cancel(MinecraftClient.getInstance(), "cancelled by command");
                            return 1;
                        }))
                        .then(ClientCommandManager.literal("reload").executes(ctx -> {
                            AutoPayConfig.reload();
                            ctx.getSource().sendFeedback(Text.literal("[AutoPay] Config reloaded"));
                            return 1;
                        }))));
    }

    private void onTick(MinecraftClient mc) {
        try {
            runner.tick(mc);

            if (--pollCooldown > 0) return;
            pollCooldown = POLL_INTERVAL_TICKS;

            AutoPayConfig cfg = AutoPayConfig.get();
            if (mc.world == null || mc.player == null || !LifestealDetector.isTargetServer(mc, cfg)) {
                resetState(mc, "not on " + cfg.serverHost);
                return;
            }

            if (LifestealDetector.isInLifesteal(mc, cfg)) {
                missCount = 0;
                if (!inLifesteal) { // false -> true transition = one entry = one run
                    inLifesteal = true;
                    runner.start(mc);
                }
            } else if (inLifesteal && ++missCount >= LEAVE_GRACE_POLLS) {
                inLifesteal = false;
                missCount = 0;
                runner.cancel(mc, "left Lifesteal");
            }
        } catch (Throwable t) {
            LOG.error("AutoPay error - cancelling run", t);
            try { runner.cancel(mc, "internal error"); } catch (Throwable ignored) { }
        }
    }

    private void resetState(MinecraftClient mc, String reason) {
        if (runner.isActive()) runner.cancel(mc, reason);
        inLifesteal = false;
        missCount = 0;
    }

    private int cmdStatus(CommandContext<FabricClientCommandSource> ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        AutoPayConfig cfg = AutoPayConfig.get();
        ctx.getSource().sendFeedback(Text.literal("[AutoPay] target server: " + LifestealDetector.isTargetServer(mc, cfg)
                + " | in Lifesteal: " + LifestealDetector.isInLifesteal(mc, cfg)
                + " | detection text: '" + LifestealDetector.detectionText(mc, cfg) + "'"
                + " | runner: " + runner.describe()));
        return 1;
    }

    private int cmdPlayers(CommandContext<FabricClientCommandSource> ctx) {
        var list = runner.snapshotPlayers(MinecraftClient.getInstance());
        ctx.getSource().sendFeedback(Text.literal("[AutoPay] " + list.size() + " players: " + String.join(", ", list)));
        return 1;
    }
}
