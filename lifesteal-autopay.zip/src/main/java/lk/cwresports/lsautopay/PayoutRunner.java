package lk.cwresports.lsautopay;

import com.mojang.authlib.GameProfile;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Matcher;

/**
 * Flow: enter Lifesteal -> settle -> snapshot players -> /balance -> split -> wait 5 s -> pay.
 * Payment order (fixed timer, never waits for server messages), 3 s after EVERY command:
 *   /pay A x ... 3s ... /pay A x ... 3s ... /pay B x ... 3s ... /pay B x ...
 * Never blocks, never opens a screen. Logged to .minecraft/lsautopay-logs/.
 */
public final class PayoutRunner {
    private enum State { IDLE, SETTLING, AWAIT_BALANCE, PAYING }

    private static final String OWN_PREFIX = "[AutoPay]";
    private static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("HH:mm:ss.SSS");
    private static final DateTimeFormatter FILE_TS = DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss");

    private State state = State.IDLE;
    private long deadline;
    private long nextSendAt;
    private final List<String> players = new ArrayList<>();
    private final Deque<String> queue = new ArrayDeque<>(); // ready-to-send commands in exact order
    private BigInteger amount = BigInteger.ZERO;
    private int total;
    private int sent;
    private Path logFile;

    public boolean isActive() { return state != State.IDLE; }

    public String describe() {
        return state + (state == State.PAYING ? " (" + sent + "/" + total + " commands, " + amount + " each)" : "");
    }

    /** Begin one run (call once per Lifesteal entry). */
    public void start(MinecraftClient mc) {
        AutoPayConfig cfg = AutoPayConfig.get();
        reset();
        try {
            Path dir = FabricLoader.getInstance().getGameDir().resolve("lsautopay-logs");
            Files.createDirectories(dir);
            logFile = dir.resolve("run-" + FILE_TS.format(LocalDateTime.now()) + ".txt");
        } catch (IOException e) {
            logFile = null;
        }
        state = State.SETTLING;
        deadline = System.currentTimeMillis() + cfg.settleDelayMs;
        runLog("Entered Lifesteal - starting in " + cfg.settleDelayMs + " ms"); // log only, no chat message
    }

    public void cancel(MinecraftClient mc, String reason) {
        if (state == State.IDLE) return;
        say(mc, "Cancelled: " + reason + " (sent " + sent + "/" + total + " commands)");
        reset();
    }

    private void finish(MinecraftClient mc, String msg) {
        say(mc, msg);
        reset();
    }

    private void reset() {
        state = State.IDLE;
        queue.clear();
        players.clear();
        sent = 0;
        total = 0;
    }

    /** Real usernames from the tab list's GameProfiles (never display names), excluding yourself. */
    public List<String> snapshotPlayers(MinecraftClient mc) {
        AutoPayConfig cfg = AutoPayConfig.get();
        List<String> out = new ArrayList<>();
        ClientPlayNetworkHandler h = mc.getNetworkHandler();
        if (h == null || mc.player == null) return out;
        UUID selfId = mc.player.getUuid();
        String selfName = mc.getSession().getUsername();
        Set<String> seen = new HashSet<>();
        for (PlayerListEntry e : h.getPlayerList()) {
            GameProfile p = e.getProfile();
            if (p == null) continue;
            String name = p.name();
            if (name == null || name.isEmpty()) continue;
            if (selfId.equals(p.id()) || name.equalsIgnoreCase(selfName)) continue;
            if (!cfg.usernamePattern.matcher(name).matches()) continue;
            if (seen.add(name.toLowerCase(Locale.ROOT))) out.add(name);
        }
        return out;
    }

    public void tick(MinecraftClient mc) {
        if (state == State.IDLE) return;
        AutoPayConfig cfg = AutoPayConfig.get();
        ClientPlayNetworkHandler h = mc.getNetworkHandler();
        if (h == null || mc.player == null) {
            cancel(mc, "disconnected");
            return;
        }
        long now = System.currentTimeMillis();

        if (state == State.SETTLING) {
            if (now < deadline) return;
            // Snapshot ONCE. Players who join later are never added.
            players.addAll(snapshotPlayers(mc));
            if (players.isEmpty()) {
                finish(mc, "No other players found - nothing to do.");
                return;
            }
            runLog("players: " + String.join(", ", players));
            say(mc, "Found " + players.size() + " other players. Reading balance...");
            h.sendChatCommand(cfg.balanceCommand);
            state = State.AWAIT_BALANCE;
            deadline = now + cfg.balanceTimeoutMs;

        } else if (state == State.AWAIT_BALANCE) {
            if (now >= deadline) finish(mc, "No balance reply - aborted, nothing paid.");

        } else if (state == State.PAYING) {
            if (now < nextSendAt) return;
            // Never send while not on the server / in Lifesteal (pauses; the main loop cancels after a short grace).
            if (!LifestealDetector.isActive(mc, cfg)) return;
            String cmd = queue.pollFirst();
            if (cmd == null) {
                finish(mc, "Done.");
                return;
            }
            sent++;
            runLog("SEND /" + cmd + "  (" + sent + "/" + total + ")");
            h.sendChatCommand(cmd);
            nextSendAt = now + cfg.commandDelayMs; // fixed gap after EVERY command
            if (queue.isEmpty()) finish(mc, "Done: " + players.size() + " players paid " + amount + " each.");
        }
    }

    /** Feed system chat messages here: reads the /balance reply, watches for error messages while paying. */
    public void onGameMessage(String text) {
        if (state == State.IDLE || text == null || text.startsWith(OWN_PREFIX)) return;
        AutoPayConfig cfg = AutoPayConfig.get();
        MinecraftClient mc = MinecraftClient.getInstance();
        if (state != State.SETTLING) runLog("MSG: " + text);

        if (state == State.AWAIT_BALANCE) {
            Matcher m = cfg.balancePattern.matcher(text);
            if (!m.find()) return;
            BigDecimal balance = parseBalance(m.group(1), m.groupCount() >= 2 ? m.group(2) : null);
            if (balance == null) return;
            beginPaying(mc, cfg, balance);

        } else if (state == State.PAYING) {
            if (cfg.abortPattern.matcher(text).find()) {
                cancel(mc, "server said: " + text);
            }
        }
    }

    private void beginPaying(MinecraftClient mc, AutoPayConfig cfg, BigDecimal balance) {
        BigInteger bal = balance.setScale(0, RoundingMode.FLOOR).toBigInteger();
        if (bal.signum() <= 0) {
            finish(mc, "Balance is 0 - nothing to pay.");
            return;
        }
        if (players.isEmpty()) {
            finish(mc, "Player count is 0 - nothing to pay.");
            return;
        }
        int n = players.size();
        amount = bal.divide(BigInteger.valueOf(n)); // floor(balance / count)
        if (amount.signum() <= 0) {
            finish(mc, "Amount per player would be less than 1 - skipped.");
            return;
        }
        // Exact command order: A, A, B, B, ...
        queue.clear();
        for (String name : players) {
            String cmd = cfg.payCommand + " " + name + " " + amount.toString(); // plain integer, always
            queue.addLast(cmd);
            if (cfg.confirmPay) queue.addLast(cmd);
        }
        total = queue.size();
        sent = 0;
        nextSendAt = System.currentTimeMillis() + cfg.payStartDelayMs; // wait 5 s after /balance
        state = State.PAYING;
        say(mc, "Balance " + bal + " / " + n + " players = " + amount + " each. Paying in "
                + (cfg.payStartDelayMs / 1000) + " s...");
    }

    private static BigDecimal parseBalance(String num, String suffix) {
        try {
            BigDecimal v = new BigDecimal(num.replace(",", ""));
            if (suffix != null) {
                switch (suffix.toLowerCase(Locale.ROOT)) {
                    case "k" -> v = v.multiply(BigDecimal.valueOf(1_000L));
                    case "m" -> v = v.multiply(BigDecimal.valueOf(1_000_000L));
                    case "b" -> v = v.multiply(BigDecimal.valueOf(1_000_000_000L));
                    case "t" -> v = v.multiply(BigDecimal.valueOf(1_000_000_000_000L));
                    default -> { }
                }
            }
            return v;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private void runLog(String line) {
        AutoPayClient.LOG.info(line);
        if (logFile == null) return;
        try {
            Files.writeString(logFile, "[" + LocalTime.now().format(TS) + "] " + line + "\n",
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException ignored) {
            // logging must never break a run
        }
    }

    private void say(MinecraftClient mc, String msg) {
        runLog(msg);
        if (AutoPayConfig.get().verbose && mc != null && mc.player != null) {
            mc.player.sendMessage(Text.literal(OWN_PREFIX + " " + msg), false); // local only
        }
    }
}
