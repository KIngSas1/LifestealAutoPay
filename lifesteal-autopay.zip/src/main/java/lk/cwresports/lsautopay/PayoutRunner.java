package lk.cwresports.lsautopay;

import com.mojang.authlib.GameProfile;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Matcher;

/**
 * Tick-driven state machine: settle -> snapshot players -> /balance -> pay each player.
 * Per player:
 *   1. /pay <name> <amount>
 *   2. wait for the server's "repeat ... to confirm" message (max confirmWaitMs)
 *   3. wait confirmDelayMs (default 1 s)
 *   4. /pay <name> <amount> again (confirms)
 *   5. wait commandDelayMs (default 1 s), next player
 * Never blocks, never opens a screen. Everything is logged to .minecraft/lsautopay-logs/.
 */
public final class PayoutRunner {
    private enum State { IDLE, SETTLING, AWAIT_BALANCE, PAYING }
    private enum Phase { SEND_FIRST, WAIT_PROMPT, SEND_CONFIRM }

    private static final String OWN_PREFIX = "[AutoPay]";
    private static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("HH:mm:ss.SSS");
    private static final DateTimeFormatter FILE_TS = DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss");

    private State state = State.IDLE;
    private Phase phase = Phase.SEND_FIRST;
    private long deadline;
    private long nextSendAt;
    private long promptDeadline;
    private long confirmAt;
    private final List<String> players = new ArrayList<>();
    private final Deque<String> queue = new ArrayDeque<>();
    private BigInteger amount = BigInteger.ZERO;
    private int total;
    private int sent; // players completed
    private Path logFile;

    public boolean isActive() { return state != State.IDLE; }

    public String describe() {
        return state + (state == State.PAYING ? " (" + sent + "/" + total + " players, " + amount + " each)" : "");
    }

    /** Begin one run (call once per Lifesteal entry). */
    public void start(MinecraftClient mc) {
        AutoPayConfig cfg = AutoPayConfig.get();
        reset();
        try {
            Path dir = FabricLoader.getInstance().getGameDir().resolve("lsautopay-logs");
            Files.createDirectories(dir);
            logFile = dir.resolve("run-" + FILE_TS.format(LocalDateTime.now()) + ".txt");
        } catch (IOException e) {
            logFile = null;
        }
        state = State.SETTLING;
        deadline = System.currentTimeMillis() + cfg.settleDelayMs;
        say(mc, "Entered Lifesteal - starting in " + cfg.settleDelayMs + " ms");
    }

    public void cancel(MinecraftClient mc, String reason) {
        if (state == State.IDLE) return;
        say(mc, "Cancelled: " + reason + " (" + sent + "/" + total + " players done)");
        reset();
    }

    private void finish(MinecraftClient mc, String msg) {
        say(mc, msg);
        reset();
    }

    private void reset() {
        state = State.IDLE;
        phase = Phase.SEND_FIRST;
        queue.clear();
        players.clear();
        sent = 0;
        total = 0;
    }

    /** Real usernames from the tab list's GameProfiles (never display names), excluding yourself. */
    public List<String> snapshotPlayers(MinecraftClient mc) {
        AutoPayConfig cfg = AutoPayConfig.get();
        List<String> out = new ArrayList<>();
        ClientPlayNetworkHandler h = mc.getNetworkHandler();
        if (h == null || mc.player == null) return out;
        UUID selfId = mc.player.getUuid();
        String selfName = mc.getSession().getUsername();
        Set<String> seen = new HashSet<>();
        for (PlayerListEntry e : h.getPlayerList()) {
            GameProfile p = e.getProfile();
            if (p == null) continue;
            String name = p.name();
            if (name == null || name.isEmpty()) continue;
            if (selfId.equals(p.id()) || name.equalsIgnoreCase(selfName)) continue;
            if (!cfg.usernamePattern.matcher(name).matches()) continue;
            if (seen.add(name.toLowerCase(Locale.ROOT))) out.add(name);
        }
        return out;
    }

    public void tick(MinecraftClient mc) {
        if (state == State.IDLE) return;
        AutoPayConfig cfg = AutoPayConfig.get();
        ClientPlayNetworkHandler h = mc.getNetworkHandler();
        if (h == null || mc.player == null) {
            cancel(mc, "disconnected");
            return;
        }
        long now = System.currentTimeMillis();

        if (state == State.SETTLING) {
            if (now < deadline) return;
            // Snapshot ONCE. Players who join later are never added.
            players.addAll(snapshotPlayers(mc));
            if (players.isEmpty()) {
                finish(mc, "No other players found - nothing to do.");
                return;
            }
            runLog("players: " + String.join(", ", players));
            say(mc, "Found " + players.size() + " other players. Reading balance...");
            h.sendChatCommand(cfg.balanceCommand);
            state = State.AWAIT_BALANCE;
            deadline = now + cfg.balanceTimeoutMs;

        } else if (state == State.AWAIT_BALANCE) {
            if (now >= deadline) finish(mc, "No balance reply - aborted, nothing paid.");

        } else if (state == State.PAYING) {
            // Never send while not on the server / in Lifesteal (pauses; the main loop cancels after a short grace).
            if (!LifestealDetector.isActive(mc, cfg)) return;
            String name = queue.peekFirst();
            if (name == null) {
                finish(mc, "Done.");
                return;
            }
            String cmd = cfg.payCommand + " " + name + " " + amount.toString(); // plain integer, always

            if (phase == Phase.SEND_FIRST) {
                if (now < nextSendAt) return;
                send(h, cmd, cfg.confirmPay ? "1/2" : "1/1");
                if (!cfg.confirmPay) {
                    completePlayer(mc, now);
                    return;
                }
                phase = Phase.WAIT_PROMPT;
                promptDeadline = now + cfg.confirmWaitMs;

            } else if (phase == Phase.WAIT_PROMPT) {
                if (now >= promptDeadline) {
                    runLog("no confirm prompt recognised within " + cfg.confirmWaitMs + " ms - confirming anyway");
                    confirmAt = now;
                    phase = Phase.SEND_CONFIRM;
                }

            } else { // SEND_CONFIRM
                if (now < confirmAt) return;
                send(h, cmd, "2/2 confirm");
                completePlayer(mc, now);
            }
        }
    }

    private void send(ClientPlayNetworkHandler h, String cmd, String tag) {
        runLog("SEND /" + cmd + "  (" + tag + ")");
        h.sendChatCommand(cmd);
    }

    private void completePlayer(MinecraftClient mc, long now) {
        queue.pollFirst();
        sent++;
        phase = Phase.SEND_FIRST;
        nextSendAt = now + AutoPayConfig.get().commandDelayMs;
        if (queue.isEmpty()) {
            finish(mc, "Done: " + sent + " players paid " + amount + " each.");
        }
    }

    /** Feed system chat messages here: reads the /balance reply and the confirm prompt, watches for errors. */
    public void onGameMessage(String text) {
        if (state == State.IDLE || text == null || text.startsWith(OWN_PREFIX)) return;
        AutoPayConfig cfg = AutoPayConfig.get();
        MinecraftClient mc = MinecraftClient.getInstance();
        if (state != State.SETTLING) runLog("MSG: " + text);

        if (state == State.AWAIT_BALANCE) {
            Matcher m = cfg.balancePattern.matcher(text);
            if (!m.find()) return;
            BigDecimal balance = parseBalance(m.group(1), m.groupCount() >= 2 ? m.group(2) : null);
            if (balance == null) return;
            beginPaying(mc, cfg, balance);

        } else if (state == State.PAYING) {
            if (cfg.abortPattern.matcher(text).find()) {
                cancel(mc, "server said: " + text);
                return;
            }
            if (phase == Phase.WAIT_PROMPT && cfg.promptPattern.matcher(text).find()) {
                confirmAt = System.currentTimeMillis() + cfg.confirmDelayMs;
                phase = Phase.SEND_CONFIRM;
                runLog("confirm prompt seen - sending 2nd /pay in " + cfg.confirmDelayMs + " ms");
            }
        }
    }

    private void beginPaying(MinecraftClient mc, AutoPayConfig cfg, BigDecimal balance) {
        BigInteger bal = balance.setScale(0, RoundingMode.FLOOR).toBigInteger();
        if (bal.signum() <= 0) {
            finish(mc, "Balance is 0 - nothing to pay.");
            return;
        }
        if (players.isEmpty()) {
            finish(mc, "Player count is 0 - nothing to pay.");
            return;
        }
        int n = players.size();
        amount = bal.divide(BigInteger.valueOf(n)); // floor(balance / count)
        if (amount.signum() <= 0) {
            finish(mc, "Amount per player would be less than 1 - skipped.");
            return;
        }
        queue.clear();
        queue.addAll(players);
        total = n;
        sent = 0;
        phase = Phase.SEND_FIRST;
        nextSendAt = System.currentTimeMillis();
        state = State.PAYING;
        say(mc, "Balance " + bal + " / " + n + " players = " + amount + " each");
    }

    private static BigDecimal parseBalance(String num, String suffix) {
        try {
            BigDecimal v = new BigDecimal(num.replace(",", ""));
            if (suffix != null) {
                switch (suffix.toLowerCase(Locale.ROOT)) {
                    case "k" -> v = v.multiply(BigDecimal.valueOf(1_000L));
                    case "m" -> v = v.multiply(BigDecimal.valueOf(1_000_000L));
                    case "b" -> v = v.multiply(BigDecimal.valueOf(1_000_000_000L));
                    case "t" -> v = v.multiply(BigDecimal.valueOf(1_000_000_000_000L));
                    default -> { }
                }
            }
            return v;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private void runLog(String line) {
        AutoPayClient.LOG.info(line);
        if (logFile == null) return;
        try {
            Files.writeString(logFile, "[" + LocalTime.now().format(TS) + "] " + line + "\n",
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException ignored) {
            // logging must never break a run
        }
    }

    private void say(MinecraftClient mc, String msg) {
        runLog(msg);
        if (AutoPayConfig.get().verbose && mc != null && mc.player != null) {
            mc.player.sendMessage(Text.literal(OWN_PREFIX + " " + msg), false); // local only
        }
    }
}
