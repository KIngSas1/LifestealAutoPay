package lk.cwresports.lsautopay;

import com.mojang.authlib.GameProfile;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Matcher;

/**
 * Tick-driven state machine: settle -> snapshot players -> /balance -> send commands one at a time.
 * Commands go out in this order with commandDelayMs (default 1 s) between EVERY one:
 *   /pay A x, /pay A x, /pay B x, /pay B x, ...
 * Never blocks, never opens a screen.
 */
public final class PayoutRunner {
    private enum State { IDLE, SETTLING, AWAIT_BALANCE, PAYING }

    private static final String OWN_PREFIX = "[AutoPay]";

    private State state = State.IDLE;
    private long deadline;
    private long nextSendAt;
    private final List<String> players = new ArrayList<>();
    private final Deque<String> queue = new ArrayDeque<>(); // ready-to-send commands, in order
    private BigInteger amount = BigInteger.ZERO;
    private int total;
    private int sent;

    public boolean isActive() { return state != State.IDLE; }

    public String describe() {
        return state + (state == State.PAYING ? " (" + sent + "/" + total + " commands, " + amount + " each)" : "");
    }

    /** Begin one run (call once per Lifesteal entry). */
    public void start(MinecraftClient mc) {
        AutoPayConfig cfg = AutoPayConfig.get();
        reset();
        state = State.SETTLING;
        deadline = System.currentTimeMillis() + cfg.settleDelayMs;
        say(mc, "Entered Lifesteal - starting in " + cfg.settleDelayMs + " ms");
    }

    public void cancel(MinecraftClient mc, String reason) {
        if (state == State.IDLE) return;
        say(mc, "Cancelled: " + reason + " (sent " + sent + "/" + total + " commands)");
        reset();
    }

    private void finish(MinecraftClient mc, String msg) {
        say(mc, msg);
        reset();
    }

    private void reset() {
        state = State.IDLE;
        queue.clear();
        players.clear();
        sent = 0;
        total = 0;
    }

    /** Real usernames from the tab list's GameProfiles (never display names), excluding yourself. */
    public List<String> snapshotPlayers(MinecraftClient mc) {
        AutoPayConfig cfg = AutoPayConfig.get();
        List<String> out = new ArrayList<>();
        ClientPlayNetworkHandler h = mc.getNetworkHandler();
        if (h == null || mc.player == null) return out;
        UUID selfId = mc.player.getUuid();
        String selfName = mc.getSession().getUsername();
        Set<String> seen = new HashSet<>();
        for (PlayerListEntry e : h.getPlayerList()) {
            GameProfile p = e.getProfile();
            if (p == null) continue;
            String name = p.name();
            if (name == null || name.isEmpty()) continue;
            if (selfId.equals(p.id()) || name.equalsIgnoreCase(selfName)) continue;
            if (!cfg.usernamePattern.matcher(name).matches()) continue;
            if (seen.add(name.toLowerCase(Locale.ROOT))) out.add(name);
        }
        return out;
    }

    public void tick(MinecraftClient mc) {
        if (state == State.IDLE) return;
        AutoPayConfig cfg = AutoPayConfig.get();
        ClientPlayNetworkHandler h = mc.getNetworkHandler();
        if (h == null || mc.player == null) {
            cancel(mc, "disconnected");
            return;
        }
        long now = System.currentTimeMillis();

        switch (state) {
            case SETTLING -> {
                if (now < deadline) return;
                // Snapshot ONCE. Players who join later are never added.
                players.addAll(snapshotPlayers(mc));
                if (players.isEmpty()) {
                    finish(mc, "No other players found - nothing to do.");
                    return;
                }
                say(mc, "Found " + players.size() + " other players. Reading balance...");
                h.sendChatCommand(cfg.balanceCommand);
                state = State.AWAIT_BALANCE;
                deadline = now + cfg.balanceTimeoutMs;
            }
            case AWAIT_BALANCE -> {
                if (now >= deadline) finish(mc, "No balance reply - aborted, nothing paid.");
            }
            case PAYING -> {
                if (now < nextSendAt) return;
                // Never send while not on the server / in Lifesteal (pauses; the main loop cancels after a short grace).
                if (!LifestealDetector.isActive(mc, cfg)) return;
                String cmd = queue.pollFirst();
                if (cmd == null) {
                    finish(mc, "Done.");
                    return;
                }
                AutoPayClient.LOG.info("sending /{}", cmd);
                h.sendChatCommand(cmd);
                sent++;
                nextSendAt = now + cfg.commandDelayMs; // fixed gap after EVERY command
                if (queue.isEmpty()) finish(mc, "Done: " + players.size() + " players paid " + amount + " each.");
            }
            default -> { }
        }
    }

    /** Feed system chat messages here: reads the /balance reply and watches for error messages. */
    public void onGameMessage(String text) {
        if (state == State.IDLE || text == null || text.startsWith(OWN_PREFIX)) return;
        AutoPayConfig cfg = AutoPayConfig.get();
        MinecraftClient mc = MinecraftClient.getInstance();

        if (state == State.AWAIT_BALANCE) {
            Matcher m = cfg.balancePattern.matcher(text);
            if (!m.find()) return;
            BigDecimal balance = parseBalance(m.group(1), m.groupCount() >= 2 ? m.group(2) : null);
            if (balance == null) return;
            beginPaying(mc, cfg, balance);
        } else if (state == State.PAYING) {
            if (cfg.abortPattern.matcher(text).find()) {
                cancel(mc, "server said: " + text);
            }
        }
    }

    private void beginPaying(MinecraftClient mc, AutoPayConfig cfg, BigDecimal balance) {
        BigInteger bal = balance.setScale(0, RoundingMode.FLOOR).toBigInteger();
        if (bal.signum() <= 0) {
            finish(mc, "Balance is 0 - nothing to pay.");
            return;
        }
        if (players.isEmpty()) {
            finish(mc, "Player count is 0 - nothing to pay.");
            return;
        }
        int n = players.size();
        amount = bal.divide(BigInteger.valueOf(n)); // floor(balance / count)
        if (amount.signum() <= 0) {
            finish(mc, "Amount per player would be less than 1 - skipped.");
            return;
        }
        // Build the exact command order: A, A, B, B, ...
        queue.clear();
        for (String name : players) {
            String cmd = cfg.payCommand + " " + name + " " + amount.toString(); // plain integer, always
            queue.addLast(cmd);
            if (cfg.confirmPay) queue.addLast(cmd);
        }
        total = queue.size();
        sent = 0;
        nextSendAt = System.currentTimeMillis();
        state = State.PAYING;
        say(mc, "Balance " + bal + " / " + n + " players = " + amount + " each ("
                + total + " commands, one every " + cfg.commandDelayMs + " ms)");
    }

    private static BigDecimal parseBalance(String num, String suffix) {
        try {
            BigDecimal v = new BigDecimal(num.replace(",", ""));
            if (suffix != null) {
                switch (suffix.toLowerCase(Locale.ROOT)) {
                    case "k" -> v = v.multiply(BigDecimal.valueOf(1_000L));
                    case "m" -> v = v.multiply(BigDecimal.valueOf(1_000_000L));
                    case "b" -> v = v.multiply(BigDecimal.valueOf(1_000_000_000L));
                    case "t" -> v = v.multiply(BigDecimal.valueOf(1_000_000_000_000L));
                    default -> { }
                }
            }
            return v;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private void say(MinecraftClient mc, String msg) {
        AutoPayClient.LOG.info(msg);
        if (AutoPayConfig.get().verbose && mc != null && mc.player != null) {
            mc.player.sendMessage(Text.literal(OWN_PREFIX + " " + msg), false); // local only
        }
    }
}
