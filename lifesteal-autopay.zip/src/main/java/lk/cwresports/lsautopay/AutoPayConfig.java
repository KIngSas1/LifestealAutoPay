package lk.cwresports.lsautopay;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/** Settings, stored in .minecraft/config/lifesteal-autopay.json (created on first launch). */
public final class AutoPayConfig {
    public enum DetectionMode {
        /** Sidebar (scoreboard) title contains lifestealKeyword. */
        SCOREBOARD_TITLE,
        /** Dimension/world id contains lifestealKeyword. */
        DIMENSION
    }

    // Server reply seen in your report: "[!] CWR -> Balance: $1,000" (arrow char matched by \S)
    private static final String DEFAULT_BALANCE_REGEX =
            "(?i)^\\[!\\]\\s*CWR\\s*\\S\\s*Balance:\\s*\\$?([0-9][0-9,]*(?:\\.[0-9]+)?)\\s*([kmbt])?\\s*$";
    private static final String DEFAULT_USERNAME_REGEX = "^\\.?[A-Za-z0-9_]{1,16}$";
    private static final String DEFAULT_CONFIRM_REGEX = "(?i)confirm|again|repeat|re-?type|re-?enter";
    private static final String DEFAULT_ABORT_REGEX =
            "(?i)insufficient|not enough|(?:don't|do not) have enough|can(?:'|no)t afford|too fast|slow down|unknown command";

    public String serverHost = "mc.cwresports.lk";
    public DetectionMode detectionMode = DetectionMode.SCOREBOARD_TITLE;
    /** Sidebar title in Lifesteal is "CWR LIFESTEAL" (lobby title is "CWR MC NETWORK" in small caps). */
    public String lifestealKeyword = "lifesteal";

    /** Wait after detecting Lifesteal before reading the player list (lets the tab list settle). */
    public int settleDelayMs = 3000;
    /** Delay between players. */
    public int commandDelayMs = 400;
    /** How long to wait for the /balance reply. */
    public int balanceTimeoutMs = 8000;

    public String balanceCommand = "balance";
    public String payCommand = "pay";
    /** Group 1 = number, group 2 (optional) = k/m/b/t suffix. Matched against the /balance reply. */
    public String balanceRegex = DEFAULT_BALANCE_REGEX;
    /** Only names matching this are paid (filters NPC / fake tab entries). */
    public String usernameRegex = DEFAULT_USERNAME_REGEX;

    /** The server needs /pay <name> <amount> typed twice (2nd time confirms). */
    public boolean confirmPay = true;
    /** Never send the confirming command sooner than this after the first. */
    public int confirmMinDelayMs = 300;
    /** Wait this long for a "confirm" prompt; if none is recognised the 2nd command is sent anyway. */
    public int confirmWaitMs = 2000;
    /** A server message matching this counts as the confirm prompt (sends the 2nd command right away). */
    public String confirmRegex = DEFAULT_CONFIRM_REGEX;
    /** A server message matching this during paying cancels the run (no money / rate limit / etc). */
    public String abortRegex = DEFAULT_ABORT_REGEX;

    /** Print progress messages in your own chat (local only, never sent). */
    public boolean verbose = true;

    public transient Pattern balancePattern;
    public transient Pattern usernamePattern;
    public transient Pattern confirmPattern;
    public transient Pattern abortPattern;

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    private static volatile AutoPayConfig current = load();

    public static AutoPayConfig get() { return current; }

    public static void reload() { current = load(); }

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("lifesteal-autopay.json");
    }

    private static AutoPayConfig load() {
        Path p = path();
        AutoPayConfig cfg = null;
        try {
            if (Files.exists(p)) {
                try (Reader r = Files.newBufferedReader(p)) {
                    cfg = GSON.fromJson(r, AutoPayConfig.class);
                }
            }
        } catch (Exception e) {
            AutoPayClient.LOG.error("Could not read config, using defaults", e);
        }
        if (cfg == null) cfg = new AutoPayConfig();
        cfg.validate();
        try (Writer w = Files.newBufferedWriter(p)) { // rewrite so new options appear in the file
            GSON.toJson(cfg, w);
        } catch (Exception e) {
            AutoPayClient.LOG.warn("Could not write config", e);
        }
        return cfg;
    }

    private void validate() {
        if (serverHost == null || serverHost.isBlank()) serverHost = "mc.cwresports.lk";
        if (detectionMode == null) detectionMode = DetectionMode.SCOREBOARD_TITLE;
        if (lifestealKeyword == null || lifestealKeyword.isBlank()) lifestealKeyword = "lifesteal";
        settleDelayMs = Math.max(0, settleDelayMs);
        commandDelayMs = Math.max(50, commandDelayMs);
        balanceTimeoutMs = Math.max(1000, balanceTimeoutMs);
        confirmMinDelayMs = Math.max(50, confirmMinDelayMs);
        confirmWaitMs = Math.max(confirmMinDelayMs, confirmWaitMs);
        balanceCommand = stripSlash(balanceCommand, "balance");
        payCommand = stripSlash(payCommand, "pay");
        balancePattern = compile(balanceRegex, DEFAULT_BALANCE_REGEX);
        usernamePattern = compile(usernameRegex, DEFAULT_USERNAME_REGEX);
        confirmPattern = compile(confirmRegex, DEFAULT_CONFIRM_REGEX);
        abortPattern = compile(abortRegex, DEFAULT_ABORT_REGEX);
    }

    private static String stripSlash(String s, String fallback) {
        if (s == null || s.isBlank()) return fallback;
        s = s.trim();
        return s.startsWith("/") ? s.substring(1) : s;
    }

    private static Pattern compile(String regex, String fallback) {
        try {
            return Pattern.compile(regex == null ? fallback : regex);
        } catch (PatternSyntaxException e) {
            AutoPayClient.LOG.error("Bad regex '{}', using default", regex);
            return Pattern.compile(fallback);
        }
    }
}
