# Lifesteal AutoPay (Fabric 1.21.11, client-side)

Fully automatic. Every time you enter Lifesteal on mc.cwresports.lk it:
1. waits 3 s, reads the tab list (real GameProfile names, excluding you; players who join later are ignored),
2. sends /balance and reads "[!] CWR -> Balance: $X", splits it: floor(balance / players),
3. waits 5 s, then pays on a fixed timer (3 s after every command, no waiting for messages):
   /pay A x, 3s, /pay A x, 3s, /pay B x, 3s, /pay B x, ...

Cancels if you leave Lifesteal or the server says you lack money.
Log of every run: .minecraft/lsautopay-logs/run-*.txt
Settings: config/lifesteal-autopay.json (payStartDelayMs, commandDelayMs).  Commands: /lspay status | players | cancel | reload
