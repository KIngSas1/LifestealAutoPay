# Lifesteal AutoPay (Fabric 1.21.11, client-side)

Fully automatic. Every time you enter Lifesteal on mc.cwresports.lk it:
1. waits 3 s, reads the tab list (real GameProfile names, excluding you; players who join later are ignored),
2. sends /balance and reads "[!] CWR -> Balance: $X",
3. for each player: /pay <name> <amount>, waits for the server's "repeat ... to confirm" message,
   waits 1 s, sends the same /pay again, waits 1 s, next player.

Cancels if you leave Lifesteal or the server says you lack money / are sending too fast.
Every run is logged (commands sent + server replies) to .minecraft/lsautopay-logs/run-*.txt
Settings: config/lifesteal-autopay.json.  Commands: /lspay status | players | cancel | reload
