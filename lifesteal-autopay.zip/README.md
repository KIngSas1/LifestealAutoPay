# Lifesteal AutoPay (Fabric 1.21.11, client-side)

Fully automatic. Every time you enter Lifesteal on mc.cwresports.lk it:
1. waits 3 s, reads the tab list (real GameProfile names, excluding you; players who join later are ignored),
2. sends /balance and reads "[!] CWR -> Balance: $X",
3. pays floor(balance / players) to each player with /pay <name> <amount>, sent twice per player (2nd = confirm), exactly 1 s apart: A, A, B, B ...

Cancels if you leave Lifesteal or the server says you lack money / are sending too fast.
Settings: config/lifesteal-autopay.json.  Commands: /lspay status | players | cancel | reload
