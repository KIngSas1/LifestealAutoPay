package dev.legitclient.gui;

import dev.legitclient.gui.widget.SettingWidget;
import dev.legitclient.module.Module;
import dev.legitclient.setting.Setting;
import dev.legitclient.util.Draw;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

/** A module row in a panel. Left click toggles; the +/- area or right click expands the settings. */
final class ModuleButton {

    private static final int ARROW_AREA = 20;

    private final Module module;
    private final List<SettingWidget> widgets = new ArrayList<>();
    private boolean expanded;
    private float enabledAnimation;

    private int x;
    private int y;
    private int w;

    ModuleButton(Module module) {
        this.module = module;
        for (Setting<?> setting : module.getSettings()) {
            widgets.add(SettingWidget.create(setting));
        }
        widgets.add(SettingWidget.bind(module));
        widgets.add(SettingWidget.bindMode(module));
    }

    Module getModule() {
        return module;
    }

    int height() {
        int h = Theme.MODULE_HEIGHT;
        if (expanded) {
            for (SettingWidget widget : widgets) {
                if (widget.isVisible()) {
                    h += widget.height();
                }
            }
        }
        return h;
    }

    boolean rowHovered(double mouseX, double mouseY) {
        return Draw.inside(mouseX, mouseY, x, y, w, Theme.MODULE_HEIGHT);
    }

    void render(DrawContext context, int x, int y, int w, int mouseX, int mouseY) {
        this.x = x;
        this.y = y;
        this.w = w;

        boolean hovered = rowHovered(mouseX, mouseY);
        float target = module.isEnabled() && module.isToggleable() ? 1f : 0f;
        enabledAnimation += (target - enabledAnimation) * 0.3f;

        int base = hovered ? Theme.ROW_HOVER : Theme.ROW;
        int background = Draw.blend(base, Theme.accent(), enabledAnimation * 0.22f);
        Draw.rect(context, x, y, w, Theme.MODULE_HEIGHT, Theme.bg(background));
        if (enabledAnimation > 0.02f) {
            Draw.rect(context, x, y, 2, Theme.MODULE_HEIGHT, Draw.withAlpha(Theme.accent(), Math.round(enabledAnimation * 255)));
        }

        int textColor = Draw.blend(Theme.TEXT_DIM, Theme.TEXT, Math.max(enabledAnimation, hovered ? 0.7f : 0f));
        boolean bright = module.isToggleable() ? (module.isEnabled() || hovered) : true;
        module.getIcon().draw(context, x + Theme.PADDING, y + 3, 10, bright);
        Draw.text(context, module.getName(), x + Theme.PADDING + 15, y + 4, textColor);
        Draw.text(context, expanded ? "-" : "+", x + w - Theme.PADDING - 4, y + 4, expanded ? Theme.accent() : Theme.TEXT_DIM);

        if (expanded) {
            int cursor = y + Theme.MODULE_HEIGHT;
            for (SettingWidget widget : widgets) {
                if (widget.isVisible()) {
                    widget.render(context, x, cursor, w, mouseX, mouseY);
                    cursor += widget.height();
                }
            }
        }
    }

    /** @return true if the click landed on this button or one of its settings. */
    boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (rowHovered(mouseX, mouseY)) {
            // Left click on the +/- area (or right click anywhere) expands: touch screens have no right click.
            boolean arrow = mouseX >= x + w - ARROW_AREA;
            if (button == 1 || (button == 0 && (arrow || !module.isToggleable()))) {
                expanded = !expanded;
            } else if (button == 0) {
                module.toggle();
            }
            return true;
        }
        if (expanded) {
            for (SettingWidget widget : widgets) {
                if (widget.isVisible() && widget.hit(mouseX, mouseY)) {
                    widget.click(mouseX, mouseY, button);
                    return true;
                }
            }
        }
        return false;
    }

    void mouseDragged(double mouseX) {
        if (expanded) {
            widgets.forEach(widget -> widget.drag(mouseX));
        }
    }

    void mouseReleased() {
        widgets.forEach(SettingWidget::release);
    }
}
