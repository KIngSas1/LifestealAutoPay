package dev.legitclient.module.hud;

import dev.legitclient.util.Icon;

import java.util.List;

public final class Fps extends TextHudModule {

    public Fps() {
        super("FPS", "Frames per second", 4, 16);
        icon(Icon.FPS);
        enabledByDefault();
    }

    @Override
    protected List<String> buildLines() {
        return List.of("FPS: " + mc.getCurrentFps());
    }
}
