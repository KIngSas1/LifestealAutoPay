package dev.legitclient.module.hud;

import dev.legitclient.setting.BooleanSetting;
import dev.legitclient.util.ClickTracker;
import dev.legitclient.util.Icon;

import java.util.List;

public final class Cps extends TextHudModule {

    private final BooleanSetting rightButton = add(new BooleanSetting("Right button", false));

    public Cps() {
        super("CPS", "Clicks per second", 4, 28);
        icon(Icon.CPS);
        enabledByDefault();
    }

    @Override
    protected List<String> buildLines() {
        String text = "CPS: " + ClickTracker.cps(ClickTracker.LEFT);
        if (rightButton.on()) {
            text += " | " + ClickTracker.cps(ClickTracker.RIGHT);
        }
        return List.of(text);
    }
}
