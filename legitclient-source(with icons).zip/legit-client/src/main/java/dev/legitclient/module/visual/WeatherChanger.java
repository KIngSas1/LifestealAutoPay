package dev.legitclient.module.visual;

import dev.legitclient.module.Category;
import dev.legitclient.module.Module;
import dev.legitclient.setting.ModeSetting;
import dev.legitclient.util.Icon;

/** Client-side weather. Only changes what you see; the server's weather is untouched. */
public final class WeatherChanger extends Module {

    private static WeatherChanger instance;

    private final ModeSetting weather = add(new ModeSetting("Weather", "Clear", "Clear", "Rain", "Thunder"));

    public WeatherChanger() {
        super("Weather Changer", "Changes the weather you see", Category.VISUAL);
        icon(Icon.WEATHER);
        instance = this;
    }

    public static boolean isActive() {
        return instance != null && instance.isEnabled();
    }

    /** Rain strength to render, 0..1. */
    public static float rain(float real) {
        return instance.weather.is("Clear") ? 0f : 1f;
    }

    /** Thunder strength to render, 0..1. */
    public static float thunder(float real) {
        return instance.weather.is("Thunder") ? 1f : 0f;
    }
}
